/**
 *
 * @file codelet_sgemm.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2016 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon sgemm StarPU codelet
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Hatem Ltaief
 * @author Jakub Kurzak
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Philippe Virouleau
 * @author Thierry Gautier, add sgemmt based on sgemm
 * @date 2018-11-20
 * @precisions normal z -> c d s
 *
 */
#include "common.h"
#include "xkblas.h"
#include "task_s.h"
#include "task_s_internal.h"


#ifdef KAAPI_DEBUG
#undef KAAPI_DEBUG
#endif

#define ROWDIM(v,m,n) ((v) == CblasNoTrans ? m : n)
#define COLDIM(v,m,n) ((v) == CblasNoTrans ? n : m)

#define STR_EXPAND(tok) #tok
#define TASK_NAME sgemmt
#define STRNAME  "sgemmt"
#define NAME(x) x##_##sgemmt
#define PNAME(x) sgemmt##_##x
#define NPARAM 3
#define MODE_PARAM {KAAPI_ACCESS_MODE_R,KAAPI_ACCESS_MODE_R,arg->beta == 0.0 ? KAAPI_ACCESS_MODE_W : KAAPI_ACCESS_MODE_RW}
#define ADDR_PARAM {&arg->A, &arg->B, &arg->C}
#define VIEW_PARAM {\
    { ROWDIM(arg->transA, &arg->n, &arg->k), COLDIM(arg->transA, &arg->n, &arg->k), &arg->lda},\
    { ROWDIM(arg->transB, &arg->k, &arg->n), COLDIM(arg->transB, &arg->k, &arg->n), &arg->ldb},\
    {&arg->n, &arg->n, &arg->ldc}}
#define FORMAT_TYPE kaapi_flt_format
#define SIZEOF_TYPE sizeof(float)
#define DOT_COLOR "chartreuse3"

/**
 *
 * @ingroup CORE_float
 *
 */
 typedef struct {
  int uplo;
  int transA;
  int transB;
  size_t n;
  size_t k;
  float alpha;
  kaapi_access_t A;
  size_t lda;
  kaapi_access_t B;
  size_t ldb;
  float beta;
  kaapi_access_t C;
  size_t ldc;
} NAME(Arg);

static kaapi_format_id_t NAME(task_fmtid) = 0;

void INSERT_TASK_sgemmt(
    int uplo, int transA, int transB,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *Ah, size_t Am, size_t An, size_t lda,
                       xkblas_matrix_descr_t *Bh, size_t Bm, size_t Bn, size_t ldb,
    float beta,  xkblas_matrix_descr_t *Ch, size_t Cm, size_t Cn, size_t ldc)
{
    kaapi_task_t* task;
    kaapi_thread_t* thread = xkblas_self_thread();
    size_t tasksize = sizeof(NAME(Arg)) + sizeof(kaapi_task_t);
    task = kaapi_task_alloc( thread, NAME(task_fmtid), tasksize );
    NAME(Arg)* taskarg = kaapi_task_getargst(task,NAME(Arg));

    taskarg->uplo = uplo;
    taskarg->transA = transA;
    taskarg->transB = transB;
    taskarg->n = n;
    taskarg->k = k;
    taskarg->alpha = alpha;
    kaapi_update_dependencies(thread, &taskarg->A, task,
        KAAPI_ACCESS_MODE_R, xkblas_get_handle(Ah, Am, An));
    taskarg->lda = lda;
    kaapi_update_dependencies(thread, &taskarg->B, task,
        KAAPI_ACCESS_MODE_R, xkblas_get_handle(Bh, Bm, Bn));
    taskarg->ldb = ldb;
    kaapi_update_dependencies(thread, &taskarg->C, task,
        KAAPI_ACCESS_MODE_RW, xkblas_get_handle(Ch, Cm, Cn));
    taskarg->beta = beta;
    taskarg->ldc = ldc;
    kaapi_ldid_t ldid = xkblas_get_ld(Ch, Cm, Cn );
    kaapi_task_set_ld(task, 0, ldid);
    kaapi_task_commit( thread, task );

#if defined(KAAPI_DEBUG)
  printf("%s: @:%p %s[%lu,%lu, ld:%lu]%s x @:%p %s[%lu,%lu, ld:%lu]%s -> @:%p %s[%lu,%lu, ld:%lu]\n",__func__, 
      A, kaapi_dbg_get_name(A), n, k, lda, (transA==CblasNoTrans ? "":"^t"),
      B, kaapi_dbg_get_name(B), k, n, ldb, (transB==CblasNoTrans ? "":"^t"),
      C, kaapi_dbg_get_name(C), n, n, ldc
  );
#endif
}


static void NAME(task_body_cpu)( kaapi_task_t* task, kaapi_thread_t* thread )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
#if defined(KAAPI_DEBUG)
  printf("%s: @:%p %s[%lu,%lu, ld:%lu]%s x @:%p %s[%lu,%lu, ld:%lu]%s -> @:%p %s[%lu,%lu, ld:%lu]\n",__func__, 
      arg->A.data, kaapi_dbg_get_name(arg->A.data), arg->n, arg->k, arg->lda, (arg->transA==CblasNoTrans ? "":"^t"),
      arg->B.data, kaapi_dbg_get_name(arg->B.data), arg->k, arg->n, arg->ldb, (arg->transB==CblasNoTrans ? "":"^t"),
      arg->C.data, kaapi_dbg_get_name(arg->C.data), arg->n, arg->n, arg->ldc
  );
#endif
#if defined(KAAPI_BLAS_USE_MKL)
  cblas_sgemmt(
      CblasColMajor,
      arg->uplo,
      arg->transA, arg->transB,
      arg->n, arg->k,
      (arg->alpha),
      arg->A.data, arg->lda,
      arg->B.data, arg->ldb,
      (arg->beta),
      arg->C.data, arg->ldc
  );
#else
  cblas_sgemm(
      CblasColMajor,
      arg->transA, arg->transB,
      arg->n, arg->n, arg->k,
      (arg->alpha),
      arg->A.data, arg->lda,
      arg->B.data, arg->ldb,
      (arg->beta),
      arg->C.data, arg->ldc
  );
#endif
}

#if KAAPI_USE_CUDA
static void NAME(task_body_gpu)( kaapi_task_t* task, kaapi_thread_t* thread, void* handle )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
#if defined(KAAPI_DEBUG)
  printf("%s: @:%p %s[%lu,%lu, ld:%lu]%s x @:%p %s[%lu,%lu, ld:%lu]%s -> @:%p %s[%lu,%lu, ld:%lu]\n",__func__, 
      arg->A.data, kaapi_dbg_get_name(arg->A.data), arg->n, arg->k, arg->lda, (cblas2cublas_op(arg->transA)==CUBLAS_OP_N ? "":"^t"),
      arg->B.data, kaapi_dbg_get_name(arg->B.data), arg->k, arg->n, arg->ldb, (cblas2cublas_op(arg->transB)==CUBLAS_OP_N ? "":"^t"),
      arg->C.data, kaapi_dbg_get_name(arg->C.data), arg->n, arg->n, arg->ldc
  );
#endif
  /* no equivalent cublasSgemmt */
  cublasSgemm((cublasHandle_t)handle,
      cblas2cublas_op(arg->transA), cblas2cublas_op(arg->transB),
      arg->n, arg->n, arg->k,
      (const float*)&arg->alpha,
      (const float*)arg->A.data, arg->lda,
      (const float*)arg->B.data, arg->ldb,
      (const float*)&arg->beta,
      (float*)arg->C.data, arg->ldc
  );
}
#endif


#include "task_format.h"

