/**
 *
 * @file dgemm.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon dgemm wrappers
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Thierry Gautier
 * @date 2018-11-20
 * @precisions normal z -> s d c
 * This file was merged from pdgemm and dgemm from Chameleon by Thierry Gautier
 * for Kaapi that support natively 2D memory view.
 */
#include "common.h"
#include "task_d.h"
#include "task_d_internal.h"
#include <math.h>

#ifdef KAAPI_DEBUG
#undef KAAPI_DEBUG
#endif
//#define KAAPI_DEBUG 1

/**
 ********************************************************************************
 *
 * @ingroup double
 *
 *  CHAMELEON_dgemm - Performs one of the matrix-matrix operations
 *
 *    \f[ C = \alpha [op( A )\times op( B )] + \beta C \f],
 *
 *  where op( X ) is one of
 *
 *    op( X ) = X  or op( X ) = X' or op( X ) = conjg( X' )
 *
 *  alpha and beta are scalars, and A, B and C  are matrices, with op( A )
 *  an m by k matrix, op( B ) a k by n matrix and C an m by n matrix.
 *
 *******************************************************************************
 *
 * @param[in] transA
 *          Specifies whether the matrix A is transposed, not transposed or conjugate transposed:
 *          = CblasNoTrans:   A is not transposed;
 *          = CblasTrans:     A is transposed;
 *          = CblasConjTrans: A is conjugate transposed.
 *
 * @param[in] transB
 *          Specifies whether the matrix B is transposed, not transposed or conjugate transposed:
 *          = CblasNoTrans:   B is not transposed;
 *          = CblasTrans:     B is transposed;
 *          = CblasConjTrans: B is conjugate transposed.
 *
 * @param[in] M
 *          M specifies the number of rows of the matrix op( A ) and of the matrix C. M >= 0.
 *
 * @param[in] N
 *          N specifies the number of columns of the matrix op( B ) and of the matrix C. N >= 0.
 *
 * @param[in] K
 *          K specifies the number of columns of the matrix op( A ) and the number of rows of
 *          the matrix op( B ). K >= 0.
 *
 * @param[in] alpha
 *          alpha specifies the scalar alpha
 *
 * @param[in] A
 *          A is a LDA-by-ka matrix, where ka is K when  transA = CblasNoTrans,
 *          and is  M  otherwise.
 *
 * @param[in] LDA
 *          The leading dimension of the array A. LDA >= max(1,M).
 *
 * @param[in] B
 *          B is a LDB-by-kb matrix, where kb is N when  transB = CblasNoTrans,
 *          and is  K  otherwise.
 *
 * @param[in] LDB
 *          The leading dimension of the array B. LDB >= max(1,N).
 *
 * @param[in] beta
 *          beta specifies the scalar beta
 *
 * @param[in,out] C
 *          C is a LDC-by-N matrix.
 *          On exit, the array is overwritten by the M by N matrix ( alpha*op( A )*op( B ) + beta*C )
 *
 * @param[in] LDC
 *          The leading dimension of the array C. LDC >= max(1,M).
 *
 *******************************************************************************
 *
 * @return
 *          \retval 0 successful exit
 *
 *******************************************************************************
 *
 * @sa CHAMELEON_dgemm_Tile
 * @sa CHAMELEON_cgemm
 * @sa CHAMELEON_dgemm
 * @sa CHAMELEON_sgemm
 *
 */

#define A(m, n) A##h,  m,  n
#define B(m, n) B##h,  m,  n
#define C(m, n) C##h,  m,  n

int xkblas_dgemm_async(
    int transA, int transB, int M, int N, int K,
    const double* alpha, const double *A, int LDA,
                              const double *B, int LDB,
    const double* beta,        double *C, int LDC )
{
    size_t Am, An, Bm, Bn;

    /* Check input arguments */
    if ((transA < CblasNoTrans) || (transA > CblasConjTrans)) {
        kaapi_error("dgemm", "illegal value of transA");
        return -1;
    }
    if ((transB < CblasNoTrans) || (transB > CblasConjTrans)) {
        kaapi_error("dgemm", "illegal value of transB");
        return -2;
    }
    if ( transA == CblasNoTrans ) {
        Am = M; An = K;
    } else {
        Am = K; An = M;
    }
    if ( transB == CblasNoTrans ) {
        Bm = K; Bn = N;
    } else {
        Bm = N; Bn = K;
    }
    if (M < 0) {
        kaapi_error("dgemm",  "illegal value of M");
        return -3;
    }
    if (N < 0) {
        kaapi_error("dgemm", "illegal value of N");
        return -4;
    }
    if (K < 0) {
        kaapi_error("dgemm", "illegal value of N");
        return -5;
    }
    if (LDA < kaapi_max(1, Am)) {
        kaapi_error("dgemm", "illegal value of LDA");
        return -8;
    }
    if (LDB < kaapi_max(1, Bm)) {
        kaapi_error("dgemm", "illegal value of LDB");
        return -10;
    }
    if (LDC < kaapi_max(1, M)) {
        kaapi_error("dgemm", "illegal value of LDC");
        return -13;
    }

    /* Quick return */
    if (M == 0 || N == 0 ||
      ((*alpha == 0.0 || K == 0) && *beta == 1.0))
        return 0;

    size_t Cmb = 0;
    size_t Cnb = 0;
    size_t Amb = 0;
    size_t Anb = 0;
    size_t Bmb = 0;
    size_t Bnb = 0;

    /* get default tile size and initialize internal descriptor if not yet */
    size_t NB = xkblas_auto_nb(KERN_GEMM,M,N,K);
    xkblas_matrix_descr_t* Ah = xkblas_find(A);
    xkblas_matrix_descr_t* Bh = xkblas_find(B);
    xkblas_matrix_descr_t* Ch = xkblas_find(C);

    if (!xkblas_matrix_descr_isinit(Ah))
    {
      xkblas_init_matrix_handle(Ah, (void*)A, Am, An, LDA, sizeof(double), NB, NB);
      kaapi_assert_debug( (Ah->ld == LDA) && (Ah->M == Am) && (Ah->N == An) );
    }
    if (!xkblas_matrix_descr_isinit(Bh))
    {
      xkblas_init_matrix_handle(Bh, (void*)B, Bm, Bn, LDB, sizeof(double), NB, NB);
      kaapi_assert_debug( (Bh->ld == LDB) && (Bh->M == Bm) && (Bh->N == Bn) );
    }
    if (!xkblas_matrix_descr_isinit(Ch))
    {
      xkblas_init_matrix_handle(Ch, C, M, N, LDC, sizeof(double), NB, NB);
      kaapi_assert_debug( (Ch->ld == LDC) && (Ch->M == M) && (Ch->N == N) );
    }

    Cmb = Ch->mb;
    Cnb = Ch->nb;
    size_t Cmt = Ch->mt;
    size_t Cnt = Ch->nt;

    Amb = Ah->mb;
    Anb = Ah->nb;
    size_t Amt = Ah->mt;
    size_t Ant = Ah->nt;

    Bmb = Bh->mb;
    Bnb = Bh->nb;
    size_t Bmt = Bh->mt;
    size_t Bnt = Bh->nt;

    size_t m, n, k;
    size_t ldam, ldak, ldbn, ldbk, ldcm;
    size_t tempmm, tempnn, tempkn, tempkm;

    double zbeta;

    xkblas_auto_map( KERN_GEMM, Ch );

    for (m = 0; m < Cmt; m++)
    {
        tempmm = m == Cmt-1 ? M-m*Cmb : Cmb;
        ldcm = LDC; //BLKLDD(C, m);
        for (n = 0; n < Cnt; n++)
        {
            tempnn = n == Cnt-1 ? N-n*Cnb : Cnb;
            /*
             *  A: CblasNoTrans / B: CblasNoTrans
             */
            if (transA == CblasNoTrans)
            {
                ldam = LDA; //BLKLDD(A, m);
                if (transB == CblasNoTrans)
                {
                    for (k = 0; k < Ant; k++)
                    {
                        tempkn = k == Ant-1 ? An-k*Anb : Anb;
                        ldbk = LDB; //BLKLDD(B, k);
                        zbeta = k == 0 ? *beta : 1.0;
                        INSERT_TASK_dgemm(
                            transA, transB,
                            tempmm, tempnn, tempkn, 
                            *alpha, A(m, k), ldam,  /* lda * Z */
                                   B(k, n), ldbk,  /* ldb * Y */
                            zbeta, C(m, n), ldcm); /* ldc * Y */
                    }
                }
                /*
                 *  A: CblasNoTrans / B: Cham[Conj]Trans
                 */
                else {
                    ldbn = LDB; //BLKLDD(B, n);
                    for (k = 0; k < Ant; k++)
                    {
                        tempkn = k == Ant-1 ? An-k*Anb : Anb;
                        zbeta = k == 0 ? *beta : 1.0;
                        INSERT_TASK_dgemm(
                            transA, transB,
                            tempmm, tempnn, tempkn, 
                            *alpha, A(m, k), ldam,  /* lda * Z */
                                    B(n, k), ldbn,  /* ldb * Z */
                            zbeta,  C(m, n), ldcm); /* ldc * Y */
                    }
                }
            }
            /*
             *  A: Cham[Conj]Trans / B: CblasNoTrans
             */
            else
            {
                if (transB == CblasNoTrans)
                {
                    for (k = 0; k < Amt; k++)
                    {
                        tempkm = k == Amt-1 ? Am-k* Amb : Amb;
                        ldak = LDA; //BLKLDD(A, k);
                        ldbk = LDB; //BLKLDD(B, k);
                        zbeta = k == 0 ? *beta : 1.0;
                        INSERT_TASK_dgemm(
                            transA, transB,
                            tempmm, tempnn, tempkm, 
                            *alpha, A(k, m), ldak,  /* lda * X */
                                    B(k, n), ldbk,  /* ldb * Y */
                            zbeta,  C(m, n), ldcm); /* ldc * Y */
                    }
                }
                /*
                 *  A: Cham[Conj]Trans / B: Cham[Conj]Trans
                 */
                else
                {
                    ldbn = LDB; //BLKLDD(B, n);
                    for (k = 0; k < Amt; k++)
                    {
                        tempkm = k == Amt-1 ? Am-k* Amb : Amb;
                        ldak = LDA; //BLKLDD(A, k);
                        zbeta = k == 0 ? *beta : 1.0;
                        INSERT_TASK_dgemm(
                            transA, transB,
                            tempmm, tempnn, tempkm, 
                            *alpha, A(k, m), ldak,  /* lda * X */
                                    B(n, k), ldbn,  /* ldb * Z */
                            zbeta,  C(m, n), ldcm); /* ldc * Y */
                    }
                }
            }
        }
    }
    return 0;
}
