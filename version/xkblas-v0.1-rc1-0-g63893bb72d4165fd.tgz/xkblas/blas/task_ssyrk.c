/**
 *
 * @file quark/codelet_strsm.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon strsm Quark codelet
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Hatem Ltaief
 * @author Jakub Kurzak
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Philippe Virouleau
 * @author Thierry Gautier
 * @date 2018-11-20
 * @precisions normal z -> c d s
 *
 */
#include "common.h"
#include "xkblas.h"
#include "task_s.h"
#include "task_s_internal.h"

#ifdef KAAPI_DEBUG
#undef KAAPI_DEBUG
#endif

#define ROWDIM(v,m,n) ((v) == CblasNoTrans ? m : n)
#define COLDIM(v,m,n) ((v) == CblasNoTrans ? n : m)

#define STR_EXPAND(tok) #tok
#define TASK_NAME ssyrk
#define STRNAME  "ssyrk"
#define NAME2(x,s) x##_##s
#define NAME(x) NAME2(x,ssyrk)
#define PNAME(x) ssyrk##_##x
#define NPARAM 2
#define MODE_PARAM {KAAPI_ACCESS_MODE_R,KAAPI_ACCESS_MODE_RW }
#define ADDR_PARAM {&arg->A, &arg->B}
#define VIEW_PARAM {\
    { ROWDIM(arg->trans, &arg->n, &arg->k), COLDIM(arg->trans, &arg->n, &arg->k), &arg->lda}, \
    { &arg->n, &arg->n, &arg->ldb} }
#define FORMAT_TYPE kaapi_flt_format
#define SIZEOF_TYPE sizeof(float)
#define DOT_COLOR "darkorchid2"

/**
 *
 * @ingroup CORE_float
 *
 */
 typedef struct {
  int uplo;
  int trans;
  size_t n;
  size_t k;
  float alpha;
  kaapi_access_t A;
  size_t lda;
  float beta;
  kaapi_access_t B;
  size_t ldb;
 } NAME(Arg);

static kaapi_format_id_t NAME(task_fmtid) = 0;

void INSERT_TASK_ssyrk(
    int uplo, int trans,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *Ah, size_t Am, size_t An, size_t lda,
    float beta,  xkblas_matrix_descr_t *Bh, size_t Bm, size_t Bn, size_t ldb)
{
    kaapi_task_t* task;
    kaapi_thread_t* thread = xkblas_self_thread();
    size_t tasksize = sizeof(NAME(Arg)) + sizeof(kaapi_task_t);
    task = kaapi_task_alloc( thread, NAME(task_fmtid), tasksize );
    NAME(Arg)* taskarg = kaapi_task_getargst(task,NAME(Arg));

    taskarg->uplo = uplo;
    taskarg->trans = trans;
    taskarg->n = n;
    taskarg->k = k;
    taskarg->alpha = alpha;
    kaapi_update_dependencies(thread, &taskarg->A, task,
        KAAPI_ACCESS_MODE_R, xkblas_get_handle(Ah, Am, An));
    taskarg->lda = lda;
    taskarg->beta = beta;
    kaapi_update_dependencies(thread, &taskarg->B, task,
        KAAPI_ACCESS_MODE_RW, xkblas_get_handle(Bh, Bm, Bn));
    taskarg->ldb = ldb;
    kaapi_task_set_ld(task, 0, xkblas_get_ld(Bh, Bm, Bn));
    kaapi_task_commit( thread, task );
}


static void NAME(task_body_cpu)( kaapi_task_t* task, kaapi_thread_t* thread )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
  cblas_ssyrk(
      CblasColMajor,
      arg->uplo, arg->trans,
      arg->n, arg->k,
      (arg->alpha), arg->A.data, arg->lda,
      (arg->beta), arg->B.data, arg->ldb);
}

#if KAAPI_USE_CUDA
static void NAME(task_body_gpu)( kaapi_task_t* task, kaapi_thread_t* thread, void* handle )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
  cublasSsyrk((cublasHandle_t)handle,
        cblas2cublas_uplo(arg->uplo), cblas2cublas_op(arg->trans),
        arg->n, arg->k,
        (const float*)&arg->alpha, arg->A.data, arg->lda,
        (const float*)&arg->beta, arg->B.data, arg->ldb);
}
#endif

#include "task_format.h"
