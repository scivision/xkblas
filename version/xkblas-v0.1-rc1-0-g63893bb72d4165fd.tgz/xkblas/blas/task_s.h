/*
** Copyright 2009-2013,2018,2019 INRIA
**
** Contributors :
**
** thierry.gautier@inrialpes.fr
**
** This software is a computer program whose purpose is to execute
** blas subroutines on multi-GPUs system.
**
** This software is governed by the CeCILL-C license under French law and
** abiding by the rules of distribution of free software.  You can  use,
** modify and/ or redistribute the software under the terms of the CeCILL-C
** license as circulated by CEA, CNRS and INRIA at the following URL
** "http://www.cecill.info".

** As a counterpart to the access to the source code and  rights to copy,
** modify and redistribute granted by the license, users are provided only
** with a limited warranty  and the software's author,  the holder of the
** economic rights,  and the successive licensors  have only  limited
** liability.

** In this respect, the user's attention is drawn to the risks associated
** with loading,  using,  modifying and/or developing or reproducing the
** software by the user in light of its specific status of free software,
** that may mean  that it is complicated to manipulate,  and  that  also
** therefore means  that it is reserved for developers  and  experienced
** professionals having in-depth computer knowledge. Users are therefore
** encouraged to load and test the software's suitability as regards their
** requirements in conditions enabling the security of their systems and/or
** data to be ensured and,  more generally, to use and operate it in the
** same conditions as regards security.

** The fact that you are presently reading this means that you have had
** knowledge of the CeCILL-C license and that you accept its terms.
**/

#ifndef _kblas_task_s
#define _kblas_task_s

void INSERT_TASK_sgemm(
    int transA, int transB,
    size_t m, size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
                       xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb,
    float beta,  xkblas_matrix_descr_t *C, size_t Cm, size_t Cn, size_t ldc
);
void register_format_sgemm(void);

void INSERT_TASK_sgemmt(
    int uplo, int transA, int transB,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
                       xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb,
    float beta,  xkblas_matrix_descr_t *C, size_t Cm, size_t Cn, size_t ldc
);
void register_format_sgemmt(void);

void INSERT_TASK_strsm(
    int side, int uplo, int transA, int diag,
    size_t m, size_t n, 
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
    xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb
);
void register_format_strsm(void);

void INSERT_TASK_strmm(
    int side, int uplo, int transA, int diag,
    size_t m, size_t n,
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
    xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb
);
void register_format_strmm(void);


void INSERT_TASK_ssyrk(
    int uplo, int trans,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
    float beta,  xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb
);
void register_format_ssyrk(void);

void INSERT_TASK_ssyr2k(
    int uplo, int trans,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *Ah, size_t Am, size_t An, size_t lda,
                       xkblas_matrix_descr_t *Bh, size_t Bm, size_t Bn, size_t ldb,
    float beta,  xkblas_matrix_descr_t *Ch, size_t Cm, size_t Cn, size_t ldc
);
void register_format_ssyr2k(void);

void INSERT_TASK_ssymm(
    int side, int uplo,
    size_t m, size_t n,
    float alpha, xkblas_matrix_descr_t *A, int Am, int An, int lda,
                       xkblas_matrix_descr_t *B, int Bm, int Bn, int ldb,
    float beta,  xkblas_matrix_descr_t *C, int Cm, int Cn, int ldc
);
void register_format_ssymm(void);

void INSERT_TASK_ssyrk(
    int uplo, int trans,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda,
    float beta,  xkblas_matrix_descr_t *B, size_t Bm, size_t Bn, size_t ldb
);
void register_format_ssyrk(void);

void INSERT_TASK_ssyr2k(
    int uplo, int trans,
    size_t n, size_t k,
    float alpha, xkblas_matrix_descr_t *Ah, size_t Am, size_t An, size_t lda,
                       xkblas_matrix_descr_t *Bh, size_t Bm, size_t Bn, size_t ldb,
    float beta,   xkblas_matrix_descr_t *Ch, size_t Cm, size_t Cn, size_t ldc
);
void register_format_ssyr2k(void);

void INSERT_TASK_shemm(
    int side, int uplo,
    int m, int n,
    float alpha, xkblas_matrix_descr_t *A, int Am, int An, int lda,
                       xkblas_matrix_descr_t *B, int Bm, int Bn, int ldb,
    float beta,  xkblas_matrix_descr_t *C, int Cm, int Cn, int ldc
);
void register_format_shemm(void);

void INSERT_TASK_spotrf(
    int uplo,
    size_t n,
    xkblas_matrix_descr_t *A, size_t Am, size_t An, size_t lda
);
void register_format_spotrf(void);

#endif

