/**
 *
 * @file parsec/codelet_chemm.c
 *
 * @copyright 2009-2015 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon chemm PaRSEC codelet
 *
 * @version 1.0.0
 * @author Reazul Hoque
 * @author Thierry Gautier
 * @precisions normal z -> c
 *
 */
#include "common.h"
#include "xkblas.h"
#include "task_c.h"
#include "task_c_internal.h"

#define ROWDIM(v,m,n) ((v) == CblasLeft ? m : n)
#define COLDIM(v,m,n) ((v) == CblasLeft ? n : m)


#define STR_EXPAND(tok) #tok
#define TASK_NAME chemm
#define STRNAME  "chemm"
#define NAME(x) x##_##chemm
#define PNAME(x) chemm##_##x
#define NPARAM 3
#define MODE_PARAM {KAAPI_ACCESS_MODE_R, KAAPI_ACCESS_MODE_R, arg->beta == 0.0 ? KAAPI_ACCESS_MODE_W : KAAPI_ACCESS_MODE_RW}
#define ADDR_PARAM {&arg->A, &arg->B, &arg->C}
#define VIEW_PARAM {\
    { ROWDIM(arg->side, &arg->m, &arg->n), ROWDIM(arg->side, &arg->m, &arg->n), &arg->lda},\
    { &arg->m, &arg->n, &arg->ldb},\
    { &arg->m, &arg->n, &arg->ldc}}
#define FORMAT_TYPE kaapi_scplx_format
#define SIZEOF_TYPE sizeof(Complex32_t)
#define DOT_COLOR "chartreuse1"

/**
 *
 * @ingroup TASK_Complex32_t
 *
 */
 typedef struct {
  int side;
  int uplo;
  size_t m;
  size_t n;
  Complex32_t alpha;
  kaapi_access_t A;
  size_t lda;
  kaapi_access_t B;
  size_t ldb;
  Complex32_t beta;
  kaapi_access_t C;
  size_t ldc;
} NAME(Arg);

static kaapi_format_id_t NAME(task_fmtid) = 0;

void INSERT_TASK_chemm(
    int side, int uplo,
    int m, int n, 
    Complex32_t alpha, xkblas_matrix_descr_t *Ah, int Am, int An, int lda,
                       xkblas_matrix_descr_t *Bh, int Bm, int Bn, int ldb,
    Complex32_t beta,  xkblas_matrix_descr_t *Ch, int Cm, int Cn, int ldc
)
{
    kaapi_task_t* task;
    kaapi_thread_t* thread = xkblas_self_thread();
    size_t tasksize = sizeof(NAME(Arg)) + sizeof(kaapi_task_t);
    task = kaapi_task_alloc( thread, NAME(task_fmtid), tasksize );
    NAME(Arg)* taskarg = kaapi_task_getargst(task,NAME(Arg));

    taskarg->side = side;
    taskarg->uplo = uplo;
    taskarg->m = m;
    taskarg->n = n;
    taskarg->alpha = alpha;
    kaapi_update_dependencies(thread, &taskarg->A, task,
        KAAPI_ACCESS_MODE_R, xkblas_get_handle(Ah, Am, An));
    taskarg->lda = lda;
    kaapi_update_dependencies(thread, &taskarg->B, task,
        KAAPI_ACCESS_MODE_R, xkblas_get_handle(Bh, Bm, Bn));
    taskarg->ldb = ldb;
    kaapi_update_dependencies(thread, &taskarg->C, task,
        KAAPI_ACCESS_MODE_RW, xkblas_get_handle(Ch, Cm, Cn));
    taskarg->beta = beta;
    taskarg->ldc = ldc;
    kaapi_ldid_t ldid = xkblas_get_ld(Ch, Cm, Cn );
    kaapi_task_set_ld(task, 0, ldid);
    kaapi_task_commit( thread, task );
}

static void NAME(task_body_cpu)( kaapi_task_t* task, kaapi_thread_t* thread )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
  cblas_chemm(
      CblasColMajor,
      arg->side, arg->uplo,
      arg->m, arg->n,
      &(arg->alpha),
      (Complex32_t*)arg->A.data, arg->lda,
      (Complex32_t*)arg->B.data, arg->ldb,
      &(arg->beta),
      (Complex32_t*)arg->C.data, arg->ldc
  );
}

#if KAAPI_USE_CUDA
static void NAME(task_body_gpu)( kaapi_task_t* task, kaapi_thread_t* thread, void* handle )
{
  NAME(Arg)* arg = (NAME(Arg)*)kaapi_task_getargs(task);
  cublasChemm((cublasHandle_t)handle,
      cblas2cublas_side(arg->side), cblas2cublas_uplo(arg->uplo),
      arg->m, arg->n,
      (const cuComplex*)&arg->alpha,
      (const cuComplex*)arg->A.data, arg->lda,
      (const cuComplex*)arg->B.data, arg->ldb,
      (const cuComplex*)&arg->beta,
      (cuComplex*)arg->C.data, arg->ldc
  );
}
#endif

#include "task_format.h"

