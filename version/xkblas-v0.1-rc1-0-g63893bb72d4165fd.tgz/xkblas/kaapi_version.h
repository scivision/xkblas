#define GIT_HASH v0.1-rc1-0-g63893bb72d4165fd
