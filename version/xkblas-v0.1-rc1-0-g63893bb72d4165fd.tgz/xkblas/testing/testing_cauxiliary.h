/**
 *
 * @file testing_cauxiliary.h
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon CHAMELEON_Complex32_t auxiliary testings header
 *
 * @version 1.0.0
 * @author Mathieu Faverge
 * @author Cédric Castagnède
 * @date 2010-11-15
 * @precisions normal z -> c d s
 *
 */
#ifndef _testing_cauxiliary_h_
#define _testing_cauxiliary_h_

//#include "testing.h"

#define USAGE(name, args, details)                                      \
    printf(" Proper Usage is : ./ztesting ncores ngpus nb ib " name " " args " with\n" \
           "   - ncores : number of cores\n"                            \
           "   - ngpus  : number of GPUs\n"                             \
           "   - nb     : define the tile size\n"                       \
           "   - ib     : define the inner tile size\n"                 \
           "   - FUNC   : name of function to test\n"                   \
           details);

#ifdef WIN32
#include <float.h>
#define isnan _isnan
#endif

#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef min
#define min(a, b) ((a) < (b) ? (a) : (b))
#endif

extern int IONE;
extern int ISEED[5];

extern int    trans[3];
extern int    uplo[2];
extern int    side[2];
extern int    diag[2];

extern char *transstr[3];
extern char *uplostr[2];
extern char *sidestr[2];
extern char *diagstr[2];


int testing_cgemm(int argc, char **argv);
int testing_ctrsm(int argc, char **argv);
int testing_ctrmm(int argc, char **argv);
int testing_csymm(int argc, char **argv);
int testing_csyrk(int argc, char **argv);
int testing_csyr2k(int argc, char **argv);
#if defined(PRECISION_z) || defined(PRECISION_c)
int testing_chemm(int argc, char **argv);
int testing_cherk(int argc, char **argv);
int testing_cher2k(int argc, char **argv);
#endif

extern void testing_cplgsy(
  Complex32_t bump, size_t N, Complex32_t *A, int lda,
                  unsigned long long int seed );

#if defined(PRECISION_z) || defined(PRECISION_c)
extern void testing_cplghe(
  Complex32_t bump, size_t N, Complex32_t *A, int lda,
                  unsigned long long int seed );
#endif

#endif /* _testing_cauxiliary_h_ */
