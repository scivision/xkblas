/**
 *
 * @file testing_ctrsm.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon ctrsm testing
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Thierry Gautier, xkblas port
 * @date 2010-11-15
 * @precisions normal z -> c d s
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <lapacke.h>
#include <cblas.h>
#define KAAPI_NO_DEFAULT_BLAS_ENUM
#define KAAPI_NO_INCLUDE_BLAS_H
#include "common.h"
#include "xkblas.h"

#include "testing_cauxiliary.h"
#include "task_c_internal.h"

#include "flops.h"

static int check_solution(int side, int uplo, int trans, int diag,
                          int M, int N, Complex32_t alpha,
                          Complex32_t *A, int LDA,
                          Complex32_t *Bref, Complex32_t *Bcham, int LDB);

static void print_matrix(Complex32_t* A, int M, int N, int ld)
{
  printf("matrix(c(");
  for (size_t i = 0; i< M; ++i)
  {
    for (size_t j = 0; j< N; ++j)
      //printf("%10f ",A[i+j*ld]);
#if defined(PRECISION_d) || defined(PRECISION_s)
      printf("%10f%s",A[i+j*ld], (((i==M-1) && (j==N-1)) ? "":","));
#else
      printf("%10f%+10fI%s",A[i+j*ld], (((i==M-1) && (j==N-1)) ? "":","));
#endif
    printf(" ");
  }
  printf("), nrow=%i, ncol=%i);\n",M,N);
}


int testing_ctrsm(int argc, char **argv)
{
    int hres = 0;
    /* Check for number of arguments*/
    if ( argc != 5 ) {
        USAGE("TRSM", "alpha M N LDA LDB",
              "   - alpha  : alpha coefficient\n"
              "   - M      : number of rows of matrices B\n"
              "   - N      : number of columns of matrices B\n"
              "   - LDA    : leading dimension of matrix A\n"
              "   - LDB    : leading dimension of matrix B\n");
        return -1;
    }

    Complex32_t alpha = (Complex32_t) atof(argv[0]);
    int M     = atoi(argv[1]);
    int N     = atoi(argv[2]);
    int LDA   = atoi(argv[3]);
    int LDB   = atoi(argv[4]);

    double eps;
    int info_solution;
    int s, u, t, d, i, k;
    double flops, fmuls, fadds, fp_per_mul, fp_per_add;

    int LDAxM = LDA*max(M,N);
    int LDBxN = LDB*max(M,N);

    Complex32_t *A      = (Complex32_t *)xkblas_malloc(LDAxM*sizeof(Complex32_t));
    Complex32_t *B      = (Complex32_t *)xkblas_malloc(LDBxN*sizeof(Complex32_t));
    Complex32_t *Binit  = (Complex32_t *)xkblas_malloc(LDBxN*sizeof(Complex32_t));
    Complex32_t *Bfinal = (Complex32_t *)xkblas_malloc(LDBxN*sizeof(Complex32_t));

    /* Check if unable to allocate memory */
    if ( (!A) || (!B) || (!Binit) || (!Bfinal) )
    {
        xkblas_free(A,LDAxM*sizeof(Complex32_t)); xkblas_free(B,LDBxN*sizeof(Complex32_t));
        xkblas_free(Binit,LDBxN*sizeof(Complex32_t)); xkblas_free(Bfinal,LDBxN*sizeof(Complex32_t));
        printf("Out of Memory \n ");
        return -2;
    }

    eps = LAPACKE_slamch_work('e');

    printf("\n");
    printf("------ TESTS FOR CHAMELEON cTRSM ROUTINE -------  \n");
    printf("            Size of the Matrix B : %d by %d\n", M, N);
    printf("\n");
    printf(" The matrix A is randomly generated for each test.\n");
    printf("============\n");
    printf(" The relative machine precision (eps) is to be %e \n",eps);
    printf(" Computational tests pass if scaled residuals are less than 10.\n");

    /*----------------------------------------------------------
     *  TESTING cTRSM
     */

    if (sizeof(Complex32_t) == sizeof(float)) {
        fp_per_mul = 1;
        fp_per_add = 1;
    } else {
        fp_per_mul = 6;
        fp_per_add = 2;
    }

    for (s=0; s<2; s++) {
        for (u=0; u<2; u++) {
#if defined(PRECISION_z) || defined(PRECISION_c)
            for (t=0; t<3; t++) {
#else
            for (t=0; t<2; t++) {
#endif
                for (d=0; d<2; d++) {

#define ITER 5
                   double time[ITER];
                   double flops[ITER];

                   int suspicious = 0;
                   for (k=0; k<ITER; ++k)
                   {
                      /* Initialize A, B, C */
                      LAPACKE_clarnv_work(IONE, ISEED, LDAxM, A);
                      float invmax = 1.0/(float)max(M,N);
                      for(i=0;i<LDAxM;i++)
                       A[i] *= invmax;
                      for(i=0;i<max(M,N);i++)
                        A[LDA*i+i] = 1.0;
                      LAPACKE_clarnv_work(IONE, ISEED, LDBxN, B);

                      memcpy(Binit,  B, LDBxN*sizeof(Complex32_t));
                      memcpy(Bfinal, B, LDBxN*sizeof(Complex32_t));

                      /* XKBLAS cTRSM */
                      LAPACKE_clarnv_work(1, ISEED, 1, &alpha);

if ((M<=16) && (N<=16))
{
  printf("A<-\n");
  print_matrix(A, M, N, LDA);
  printf("B<-\n");
  print_matrix(Bfinal, M, N, LDB);
#if defined(PRECISION_d) || defined(PRECISION_s)
  printf("alpha<- %f;\n", alpha);
#else
  printf("alpha<- %f%+fI;\n", alpha);
#endif
}

                      double t0 = xkblas_elapsedtime();
                      xkblas_ctrsm_async(side[s], uplo[u], trans[t], diag[d], M, N, &alpha, A, LDA, Bfinal, LDB);
                      xkblas_memory_coherent_async(0, 0, M, N, Bfinal, LDB, sizeof(Complex32_t));
                      xkblas_sync();
                      double t1 = xkblas_elapsedtime();
                      xkblas_memory_invalidate_caches();

if ((M<=16) && (N<=16))
{
  printf("Res <- \n");
  print_matrix(Bfinal, M, N, LDB);
}


                      fadds = (double)(FADDS_TRSM( side[s], M, N ));
                      fmuls = (double)(FMULS_TRSM( side[s], M, N ));
                      time[k] = t1-t0;
                      flops[k] = 1e-9 * (fmuls * fp_per_mul + fadds * fp_per_add);

                      /* Check the solution */
                      if (getenv("NO_CHECK") ==0)
                      {
                        info_solution = check_solution(side[s], uplo[u], trans[t], diag[d],
                                                 M, N, alpha, A, LDA, Binit, Bfinal, LDB);
                        if (info_solution) suspicious = 1;
                      } else
                        info_solution = 0;
                    }

                    printf("***************************************************\n");
                    if (suspicious == 0) {
                      printf(" ---- TESTING cTRSM (%s, %s, %s, %s) ...... PASSED !\n",
                             sidestr[s], uplostr[u], transstr[t], diagstr[d]);
                      for (i=0; i<ITER; ++i)
                        printf("GFlosp=%f\n", flops[i]/time[i]);
                    }
                    else {
                      printf(" ---- TESTING cTRSM (%s, %s, %s, %s) ... FAILED !\n",
                             sidestr[s], uplostr[u], transstr[t], diagstr[d]);    hres++;
                    }
                    printf("***************************************************\n");
                  }
            }
        }
    }

    xkblas_free(A,LDAxM*sizeof(Complex32_t)); 
    xkblas_free(B,LDBxN*sizeof(Complex32_t));
    xkblas_free(Binit,LDBxN*sizeof(Complex32_t)); 
    xkblas_free(Bfinal,LDBxN*sizeof(Complex32_t));

    return hres;
}

/*--------------------------------------------------------------
 * Check the solution
 */
static int check_solution(int side, int uplo, int trans, int diag,
                          int M, int N, Complex32_t alpha,
                          Complex32_t *A, int LDA,
                          Complex32_t *Bref, Complex32_t *Bcham, int LDB)
{
    int info_solution;
    double Anorm, Binitnorm, Bchamnorm, Blapacknorm, Rnorm, result;
    double eps;
    Complex32_t mzone = (Complex32_t)-1.0;

    float *work = (float *)malloc(max(M, N)* sizeof(float));
    int Am, An;

    if (side == CblasLeft) {
        Am = M; An = M;
    } else {
        Am = N; An = N;
    }

    Anorm       = LAPACKE_clantr_work(LAPACK_COL_MAJOR, 'I', uplo, diag, Am, An, A, LDA, work);
    Binitnorm   = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', M, N, Bref,  LDB, work);
    Bchamnorm   = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', M, N, Bcham, LDB, work);

    cblas_ctrsm(CblasColMajor, (CBLAS_SIDE)side, (CBLAS_UPLO)uplo, (CBLAS_TRANSPOSE)trans,
                (CBLAS_DIAG)diag, M, N, &(alpha), A, LDA, Bref, LDB);

if ((M<=16) && (N<=16))
{
  printf("Rref <- \n");
  print_matrix(Bref, M, N, LDB);
}

    Blapacknorm = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', M, N, Bref, LDB, work);

    cblas_caxpy(LDB * N, &(mzone), Bcham, 1, Bref, 1);

    Rnorm = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', M, N, Bref, LDB, work);

    eps = LAPACKE_slamch_work('e');

    printf("Rnorm %e, Anorm %e, Binitnorm %e, Bchamnorm %e, Blapacknorm %e\n",
           Rnorm, Anorm, Binitnorm, Bchamnorm, Blapacknorm);

    result = Rnorm / ((Anorm + Blapacknorm) * max(M,N) * eps);

    printf("============\n");
    printf("Checking the norm of the difference against reference cTRSM \n");
    printf("-- ||Ccham - Clapack||_oo/((||A||_oo+||B||_oo).N.eps) = %e \n", result);

    if ( isinf(Blapacknorm) || isinf(Bchamnorm) || isnan(result) || isinf(result) || (result > 10.0) ) {
        printf("-- The solution is suspicious ! \n");
        info_solution = 1;
    }
    else {
        printf("-- The solution is CORRECT ! \n");
        info_solution= 0 ;
    }
    free(work);

    return info_solution;
}
