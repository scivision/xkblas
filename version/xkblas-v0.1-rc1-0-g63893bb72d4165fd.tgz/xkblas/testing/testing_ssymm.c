/**
 *
 * @file testing_ssymm.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon ssymm testing
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Thierry Gautier, xkblas port
 * @date 2010-11-15
 * @precisions normal z -> c d s
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <lapacke.h>
#include <cblas.h>
#define KAAPI_NO_DEFAULT_BLAS_ENUM
#define KAAPI_NO_INCLUDE_BLAS_H
#include "common.h"
#include "xkblas.h"

#include "testing_sauxiliary.h"
#include "task_s_internal.h"

#include "flops.h"

static int
check_solution( int side, int uplo, int M, int N,
                float alpha, float *A, int LDA,
                float *B, int LDB,
                float beta, float *Cref, float *Ccham, int LDC );

int testing_ssymm(int argc, char **argv)
{
    int hres = 0;
    /* Check for number of arguments*/
    if ( argc != 7 ){
        USAGE("SYMM", "alpha beta M N K LDA LDB LDC",
              "   - alpha : alpha coefficient \n"
              "   - beta : beta coefficient \n"
              "   - M : number of rows of matrices A and C \n"
              "   - N : number of columns of matrices B and C \n"
              "   - LDA : leading dimension of matrix A \n"
              "   - LDB : leading dimension of matrix B \n"
              "   - LDC : leading dimension of matrix C\n");
        return -1;
    }

    float alpha = (float) atof(argv[0]);
    float beta  = (float) atof(argv[1]);
    int M     = atoi(argv[2]);
    int N     = atoi(argv[3]);
    int LDA   = atoi(argv[4]);
    int LDB   = atoi(argv[5]);
    int LDC   = atoi(argv[6]);
    int MNmax = max(M, N);
    double flops, fmuls, fadds, fp_per_mul, fp_per_add;

    double eps;
    int info_solution;
    int i, j, k, s, u;
    int LDAxM = LDA*MNmax;
    int LDBxN = LDB*N;
    int LDCxN = LDC*N;

    float *A      = (float *)xkblas_malloc(LDAxM*sizeof(float));
    float *B      = (float *)xkblas_malloc(LDBxN*sizeof(float));
    float *C      = (float *)xkblas_malloc(LDCxN*sizeof(float));
    float *Cinit  = (float *)xkblas_malloc(LDCxN*sizeof(float));
    float *Cfinal = (float *)xkblas_malloc(LDCxN*sizeof(float));

    /* Check if unable to allocate memory */
    if ( (!A) || (!B) || (!C) || (!Cinit) || (!Cfinal) )
    {
        xkblas_free(A,LDAxM*sizeof(float)); xkblas_free(B,LDBxN*sizeof(float)); xkblas_free(C,LDCxN*sizeof(float));
        xkblas_free(Cinit,LDCxN*sizeof(float)); xkblas_free(Cfinal,LDCxN*sizeof(float));
        printf("Out of Memory \n ");
        return -2;
    }

    eps = LAPACKE_slamch_work('e');

    printf("\n");
    printf("------ TESTS FOR CHAMELEON sSYMM ROUTINE -------  \n");
    printf("            Size of the Matrix %d by %d\n", M, N);
    printf("\n");
    printf(" The matrix A is randomly generated for each test.\n");
    printf("============\n");
    printf(" The relative machine precision (eps) is to be %e \n",eps);
    printf(" Computational tests pass if scaled residuals are less than 10.\n");

    /*----------------------------------------------------------
    *  TESTING sSYMM
    */
    if (sizeof(float) == sizeof(float)) {
        fp_per_mul = 1;
        fp_per_add = 1;
    } else {
        fp_per_mul = 6;
        fp_per_add = 2;
    }

    for (s=0; s<2; s++) {
        for (u=0; u<2; u++) {

#define ITER 5
            double time[ITER];
            double flops[ITER];

            int suspicious = 0;
            for (k=0; k<ITER; ++k)
            {
              /* Initialize A */
              testing_splgsy( (double)0., MNmax, A, LDA, 51 );

              /* Initialize B */
              LAPACKE_slarnv_work(IONE, ISEED, LDBxN, B);

              /* Initialize C */
              LAPACKE_slarnv_work(IONE, ISEED, LDCxN, C);

              /* Initialize  Cinit / Cfinal */
              for ( i = 0; i < M; i++)
                  for (  j = 0; j < N; j++)
                      Cinit[LDC*j+i] = C[LDC*j+i];
              for ( i = 0; i < M; i++)
                  for (  j = 0; j < N; j++)
                      Cfinal[LDC*j+i] = C[LDC*j+i];

              LAPACKE_slarnv_work(1, ISEED, 1, &alpha);
              LAPACKE_slarnv_work(1, ISEED, 1, &beta);

              double t0 = xkblas_elapsedtime();
              /* XKBLAS sSYMM */
              xkblas_ssymm_async(side[s], uplo[u], M, N, alpha, A, LDA, B, LDB, beta, Cfinal, LDC);
              xkblas_memory_coherent_async(0, 0, M, N, Cfinal, LDC, sizeof(float));
              xkblas_sync();
              double t1 = xkblas_elapsedtime();
              xkblas_memory_invalidate_caches();

              fadds = (double)(FADDS_SYMM(side[s],M,N));
              fmuls = (double)(FMULS_SYMM(side[s],M,N));
              flops[k] = 1e-9 * (fmuls * fp_per_mul + fadds * fp_per_add);
              time[k] = t1-t0;

              /* Check the solution */
              if (getenv("NO_CHECK") ==0)
              {
                info_solution = check_solution(side[s], uplo[u], M, N, alpha, A, LDA, B, LDB, beta, Cinit, Cfinal, LDC);
                if (info_solution) suspicious = 1;
              } else
                info_solution = 0;
            }

            printf("***************************************************\n");
            if (suspicious == 0) {
                printf(" ---- TESTING sSYMM (%5s, %5s) ....... PASSED !\n", sidestr[s], uplostr[u]);
                for (i=0; i<ITER; ++i)
                  printf("GFlosp=%f\n", flops[i]/time[i]);
            }
            else {
                printf(" - TESTING sSYMM (%s, %s) ... FAILED !\n", sidestr[s], uplostr[u]);    hres++;
            }
            printf("***************************************************\n");
        }
    }

    xkblas_free(A,LDAxM*sizeof(float)); xkblas_free(B,LDBxN*sizeof(float)); xkblas_free(C,LDCxN*sizeof(float));
    xkblas_free(Cinit,LDCxN*sizeof(float)); xkblas_free(Cfinal,LDCxN*sizeof(float));

    return hres;
}

/*--------------------------------------------------------------
 * Check the solution
 */

static int
check_solution( int side, int uplo, int M, int N,
                float alpha, float *A, int LDA,
                float *B, int LDB,
                float beta, float *Cref, float *Ccham, int LDC )
{
    int info_solution, NrowA;
    double Anorm, Bnorm, Cinitnorm, Cchamnorm, Clapacknorm, Rnorm;
    double eps;
    float beta_const;
    double result;
    float *work = (float *)malloc(max(M, N)* sizeof(float));

    beta_const  = (float)-1.0;

    NrowA = (side == CblasLeft) ? M : N;
    Anorm       = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', NrowA, NrowA, A,       LDA, work);
    Bnorm       = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', M,     N,     B,       LDB, work);
    Cinitnorm   = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', M,     N,     Cref,    LDC, work);
    Cchamnorm = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', M,     N,     Ccham, LDC, work);

    cblas_ssymm(CblasColMajor, (CBLAS_SIDE)side, (CBLAS_UPLO)uplo, M, N, (alpha), 
                       A, LDA, B, LDB, (beta), Cref, LDC);

    Clapacknorm = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', M, N, Cref, LDC, work);

    cblas_saxpy(LDC * N, (beta_const), Ccham, 1, Cref, 1);

    Rnorm = LAPACKE_slange_work(LAPACK_COL_MAJOR, 'I', M, N, Cref, LDC, work);

    eps = LAPACKE_slamch_work('e');

    printf("Rnorm %e, Anorm %e, Bnorm %e, Cinitnorm %e, Cchamnorm %e, Clapacknorm %e\n",Rnorm,Anorm,Bnorm,Cinitnorm,Cchamnorm,Clapacknorm);

    result = Rnorm / ((Anorm + Bnorm + Cinitnorm) * N * eps);

    printf("============\n");
    printf("Checking the norm of the difference against reference sSYMM \n");
    printf("-- ||Ccham - Clapack||_oo/((||A||_oo+||B||_oo+||C||_oo).N.eps) = %e \n", result );

    if ( isinf(Clapacknorm) || isinf(Cchamnorm) || isnan(result) || isinf(result) || (result > 10.0) ) {
        printf("-- The solution is suspicious ! \n");
        info_solution = 1;
    }
    else {
        printf("-- The solution is CORRECT ! \n");
        info_solution= 0 ;
    }
    free(work);
    return info_solution;
}
