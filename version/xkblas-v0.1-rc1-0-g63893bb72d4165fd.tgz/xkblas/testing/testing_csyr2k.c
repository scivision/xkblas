/**
 *
 * @file testing_csyr2k.c
 *
 * @copyright 2009-2014 The University of Tennessee and The University of
 *                      Tennessee Research Foundation. All rights reserved.
 * @copyright 2012-2018 Bordeaux INP, CNRS (LaBRI UMR 5800), Inria,
 *                      Univ. Bordeaux. All rights reserved.
 *
 ***
 *
 * @brief Chameleon csyr2k testing
 *
 * @version 1.0.0
 * @comment This file has been automatically generated
 *          from Plasma 2.5.0 for CHAMELEON 1.0.0
 * @author Mathieu Faverge
 * @author Emmanuel Agullo
 * @author Cedric Castagnede
 * @author Thierry Gautier, xkblas port
 * @date 2010-11-15
 * @precisions normal z -> c d s
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <lapacke.h>
#include <cblas.h>
#define KAAPI_NO_DEFAULT_BLAS_ENUM
#define KAAPI_NO_INCLUDE_BLAS_H
#include "common.h"
#include "xkblas.h"

#include "testing_cauxiliary.h"
#include "task_c_internal.h"

#include "flops.h"

static int check_solution(int uplo, int trans, int N, int K,
                          Complex32_t alpha, Complex32_t *A, int LDA,
                          Complex32_t *B, int LDB,
                          Complex32_t beta,  Complex32_t *Cref, Complex32_t *Ccham, int LDC);


int testing_csyr2k(int argc, char **argv)
{
    int hres = 0;
    /* Check for number of arguments*/
    if ( argc != 7 ){
        USAGE("SYR2K", "alpha beta M N LDA LDB LDC",
              "   - alpha : alpha coefficient\n"
              "   - beta : beta coefficient\n"
              "   - N : number of columns and rows of matrix C and number of row of matrix A and B\n"
              "   - K : number of columns of matrix A and B\n"
              "   - LDA : leading dimension of matrix A\n"
              "   - LDB : leading dimension of matrix B\n"
              "   - LDC : leading dimension of matrix C\n");
        return -1;
    }

    Complex32_t alpha = (Complex32_t) atol(argv[0]);
    Complex32_t beta  = (Complex32_t) atol(argv[1]);
    int N     = atoi(argv[2]);
    int K     = atoi(argv[3]);
    int LDA   = atoi(argv[4]);
    int LDB   = atoi(argv[5]);
    int LDC   = atoi(argv[6]);
    int NKmax = max(N, K);
    double flops, fmuls, fadds, fp_per_mul, fp_per_add;

    double eps;
    int info_solution;
    int u, t, i, k;
    size_t LDAxK = LDA*NKmax;
    size_t LDBxK = LDB*NKmax;
    size_t LDCxN = LDC*N;

    Complex32_t *A      = (Complex32_t *)xkblas_malloc(LDAxK*sizeof(Complex32_t));
    Complex32_t *B      = (Complex32_t *)xkblas_malloc(LDBxK*sizeof(Complex32_t));
    Complex32_t *C      = (Complex32_t *)xkblas_malloc(LDCxN*sizeof(Complex32_t));
    Complex32_t *Cinit  = (Complex32_t *)xkblas_malloc(LDCxN*sizeof(Complex32_t));
    Complex32_t *Cfinal = (Complex32_t *)xkblas_malloc(LDCxN*sizeof(Complex32_t));

    /* Check if unable to allocate memory */
    if ( (!A) || (!B) || (!C) || (!Cinit) || (!Cfinal) )
    {
        xkblas_free(A,LDAxK*sizeof(Complex32_t)); 
        xkblas_free(B,LDBxK*sizeof(Complex32_t)); 
        xkblas_free(C,LDCxN*sizeof(Complex32_t));
        xkblas_free(Cinit,LDCxN*sizeof(Complex32_t)); 
        xkblas_free(Cfinal,LDCxN*sizeof(Complex32_t));
        printf("Out of Memory \n ");
        return -2;
    }

    eps = LAPACKE_slamch_work('e');

    printf("\n");
    printf("------ TESTS FOR CHAMELEON cSYR2K ROUTINE -------  \n");
    printf("            Size of the Matrix C %d by %d\n", N, K);
    printf("\n");
    printf(" The matrix A is randomly generated for each test.\n");
    printf("============\n");
    printf(" The relative machine precision (eps) is to be %e \n",eps);
    printf(" Computational tests pass if scaled residuals are less than 10.\n");

    /*----------------------------------------------------------
    *  TESTING cSYR2K
    */
    if (sizeof(Complex32_t) == sizeof(float)) {
        fp_per_mul = 1;
        fp_per_add = 1;
    } else {
        fp_per_mul = 6;
        fp_per_add = 2;
    }

    for (u=0; u<2; u++) {
        for (t=0; t<2; t++) {

#define ITER 5
            double time[ITER];
            double flops[ITER];

            int suspicious = 0;
            for (k=0; k<ITER; ++k)
            {
              /* Initialize A,B */
              LAPACKE_clarnv_work(IONE, ISEED, LDAxK, A);
              LAPACKE_clarnv_work(IONE, ISEED, LDBxK, B);

              /* Initialize C */
              testing_cplgsy( (double)0., N, C, LDC, 51 );

              memcpy(Cinit,  C, LDCxN*sizeof(Complex32_t));
              memcpy(Cfinal, C, LDCxN*sizeof(Complex32_t));

              LAPACKE_clarnv_work(1, ISEED, 1, &alpha);
              LAPACKE_clarnv_work(1, ISEED, 1, &beta);

              double t0 = xkblas_elapsedtime();
              /* XKBLAS cSYR2K */
              xkblas_csyr2k_async(uplo[u], trans[t], N, K, alpha, A, LDA, B, LDB, beta, Cfinal, LDC);
              xkblas_memory_coherent_async(uplo[u], 0, N, N, Cfinal, LDC, sizeof(Complex32_t));
              xkblas_sync();
              double t1 = xkblas_elapsedtime();
              xkblas_memory_invalidate_caches();

              fadds = (double)(FADDS_SYR2K(N,K));
              fmuls = (double)(FMULS_SYR2K(N,K));
              flops[k] = 1e-9 * (fmuls * fp_per_mul + fadds * fp_per_add);
              time[k] = t1-t0;

              /* Check the solution */
              if (getenv("NO_CHECK") ==0)
              {
                info_solution = check_solution(uplo[u], trans[t], N, K,
                                             alpha, A, LDA, B, LDB, beta, Cinit, Cfinal, LDC);
                if (info_solution) suspicious = 1;
              } else
                info_solution = 0;
            }


            printf("***************************************************\n");
            if (suspicious == 0) {
                printf(" ---- TESTING cSYR2K (%5s, %s) ........... PASSED !\n", uplostr[u], transstr[t]);
                for (i=0; i<ITER; ++i)
                  printf("GFlosp=%f\n", flops[i]/time[i]);
            }
            else {
                printf(" - TESTING cSYR2K (%5s, %s) ... FAILED !\n", uplostr[u], transstr[t]);    hres++;
            }
            printf("***************************************************\n");
        }
    }

    xkblas_free(A,LDAxK*sizeof(Complex32_t)); 
    xkblas_free(B,LDBxK*sizeof(Complex32_t)); 
    xkblas_free(C,LDCxN*sizeof(Complex32_t));
    xkblas_free(Cinit,LDCxN*sizeof(Complex32_t)); 
    xkblas_free(Cfinal,LDCxN*sizeof(Complex32_t));

    return hres;
}

/*--------------------------------------------------------------
 * Check the solution
 */

static int check_solution(int uplo, int trans, int N, int K,
                          Complex32_t alpha, Complex32_t *A, int LDA,
                          Complex32_t *B, int LDB,
                          Complex32_t beta, Complex32_t *Cref, Complex32_t *Ccham, int LDC)
{
    int info_solution;
    double Anorm, Bnorm, Cinitnorm, Cchamnorm, Clapacknorm, Rnorm, result;
    double eps;
    Complex32_t beta_const;

    float *work = (float *)malloc(max(N, K)* sizeof(float));

    beta_const  = -1.0;
    Anorm       = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I',
                                      (trans == CblasNoTrans) ? N : K,
                                      (trans == CblasNoTrans) ? K : N, A, LDA, work);
    Bnorm       = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I',
                                      (trans == CblasNoTrans) ? N : K,
                                      (trans == CblasNoTrans) ? K : N, B, LDB, work);
    Cinitnorm   = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', N, N, Cref,    LDC, work);
    Cchamnorm = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', N, N, Ccham, LDC, work);

    cblas_csyr2k(CblasColMajor, (CBLAS_UPLO)uplo, (CBLAS_TRANSPOSE)trans, N, K, 
                   &(alpha), A, LDA, B, LDB, 
                   &(beta), Cref, LDC);

    Clapacknorm = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', N, N, Cref, LDC, work);

    cblas_caxpy(LDC*N, &(beta_const), Ccham, 1, Cref, 1);

    Rnorm = LAPACKE_clange_work(LAPACK_COL_MAJOR, 'I', N, N, Cref, LDC, work);

    eps = LAPACKE_slamch_work('e');

    printf("Rnorm %e, Anorm %e, Cinitnorm %e, Cchamnorm %e, Clapacknorm %e\n",
           Rnorm, Anorm, Cinitnorm, Cchamnorm, Clapacknorm);

    result = Rnorm / ((Anorm + Bnorm + Cinitnorm) * N * eps);
    printf("============\n");
    printf("Checking the norm of the difference against reference cSYR2K \n");
    printf("-- ||Ccham - Clapack||_oo/((||A||_oo+||C||_oo).N.eps) = %e \n", result);

    if (  isnan(Rnorm) || isinf(Rnorm) || isnan(result) || isinf(result) || (result > 10.0) ) {
         printf("-- The solution is suspicious ! \n");
         info_solution = 1;
    }
    else {
         printf("-- The solution is CORRECT ! \n");
         info_solution= 0 ;
    }

    free(work);

    return info_solution;
}
